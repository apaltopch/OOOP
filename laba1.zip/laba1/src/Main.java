import java.util.Scanner;



public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем объект Scanner для ввода данных с клавиатуры

        System.out.print("Введите значение x: ");
        double x; // Считываем введенное значение x с клавиатуры и сохраняем в переменной x
        x = scanner.nextDouble();

        System.out.print("Введите значение a: ");
        double a; // Считываем введенное значение a с клавиатуры и сохраняем в переменной a7
        a = scanner.nextDouble();

        System.out.print("Введите значение b: ");
        double b; // Считываем введенное значение b с клавиатуры и сохраняем в переменной b
        b = scanner.nextDouble();

        System.out.print("Введите значение c: ");
        double c; // Считываем введенное значение c с клавиатуры и сохраняем в переменной c
        c = scanner.nextDouble();

        // Вычисляем значение функции y=f(x) по заданной формуле
        double y = (a * x + 3.8 * Math.tan(x)) / Math.sqrt(c * Math.pow(x, 3) + c * b);

        // Выводим результат вычислений на экран
        System.out.println("Значение функции y при x = " + x + ", a = " + a + ", b = " + b + ", c = " + c + " равно " + y);
    }
}
